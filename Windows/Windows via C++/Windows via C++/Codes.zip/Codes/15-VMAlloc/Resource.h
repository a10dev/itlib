//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by VMALLOC.rc
//
#define IDC_STATIC              (-1)     // all static controls
#define IDD_VMALLOC                     1
#define IDC_PAGESIZE                    100
#define IDC_RESERVE                     101
#define IDI_VMALLOC                     101
#define IDC_INDEXTEXT                   102
#define IDC_INDEX                       103
#define IDC_USE                         105
#define IDC_CLEAR                       106
#define IDC_GARBAGECOLLECT              107
#define IDC_MEMMAP                      108

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
