//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MMFSHARE.rc
//
#define IDC_STATIC              (-1)     // all static controls
#define IDD_MMFSHARE                    1
#define IDC_DATA                        100
#define IDC_CREATEFILE                  101
#define IDC_OPENFILE                    102
#define IDI_MMFSHARE                    102
#define IDC_CLOSEFILE                   103

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
