#ifdef ACT_AS_RPC_SERVER
#include "rpccalc_s.c"
#else
#include "rpccalc_c.c"
#endif
