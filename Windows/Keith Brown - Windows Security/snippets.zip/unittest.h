#pragma once

void BeginTest( const wchar_t* psz, bool bInteractive );
void EndTest();
