// NetworkAuthentication.cpp
#include "stdafx.h"

// interface dependencies
#include "NetworkAuthentication.h"

// implementation dependencies
#include "Principals.h"
#include <stdio.h>
#pragma comment(lib, "secur32.lib")

#if _WIN32_WINNT >= 0x500
void _purgeTicketCache() {
  // connect to the LSA (doesn't require TCB)
  HANDLE hLSA;
  NTSTATUS s = LsaConnectUntrusted(&hLSA);
  if (s)
    _lsaErr(L"LsaConnectUntrusted", s);
  
  // lookup the index for the Kerb authn pkg
  LSA_STRING sPackage;
  _initString(sPackage, MICROSOFT_KERBEROS_NAME_A);
  ULONG nAuthnPkg;
  s = LsaLookupAuthenticationPackage(hLSA, &sPackage,
                                     &nAuthnPkg);
  if (s)
    _lsaErr(L"LsaLookupAuthenticationPackage", s);
  
  // set up the request message
  KERB_PURGE_TKT_CACHE_REQUEST request;
  ZeroMemory(&request, sizeof request);
  request.MessageType = KerbPurgeTicketCacheMessage;
  
  // make the call
  NTSTATUS sPkg;
  s = LsaCallAuthenticationPackage(hLSA, nAuthnPkg,
                         &request, sizeof request,
                         0, 0, &sPkg);
  if (s)
    _lsaErr(L"LsaCallAuthenticationPackage", s);
  
  // figure out what actually happened
  switch (sPkg) {
  case 0:
    wprintf(L"Successfully purged ticket cache.\n");
    break;
  case SEC_E_NO_CREDENTIALS:
    wprintf(L"Ticket cache was already empty.\n");
    break;
  default:
    _lsaErr(L"KerbPurgeTicketCacheMessage", sPkg);
    break;
  }
}
#endif
