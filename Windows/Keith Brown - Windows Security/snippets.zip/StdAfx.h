// stdafx.h
#pragma once
#define UNICODE
#define _WIN32_WINNT 0x400
#include <windows.h>
#include <aclapi.h>
#include <ntsecapi.h>
