// COM.cpp
#include "stdafx.h"

// interface dependencies
#include "COM.h"

// implementation dependencies
#include "Principals.h"
#include "rpccalc.h"
#pragma comment(lib, "rpcrt4.lib")
#include <stdio.h>

void* __RPC_USER midl_user_allocate(size_t cb) { return malloc(cb); }
void  __RPC_USER midl_user_free    (void* p)   { free(p); }

long _addViaRPC(long a, long b,
                wchar_t* pszBindingString,
                wchar_t* pszExpectedServerPrincipal) {
  // get a binding handle to the server
  RPC_BINDING_HANDLE h;
  RPC_STATUS s = RpcBindingFromStringBinding(
                    pszBindingString, &h);
  if (s)
    _err(L"RpcBindingFromStringBinding", s);

  // select authn settings on the binding handle
  RPC_SECURITY_QOS sqos = {
    RPC_C_SECURITY_QOS_VERSION,
    RPC_C_QOS_CAPABILITIES_MUTUAL_AUTH,
    RPC_C_QOS_IDENTITY_STATIC,
    RPC_C_IMP_LEVEL_IDENTIFY
  };
  s = RpcBindingSetAuthInfoEx(h,
            pszExpectedServerPrincipal,
            RPC_C_AUTHN_LEVEL_PKT_INTEGRITY,
            RPC_C_AUTHN_GSS_KERBEROS,
            0,
            RPC_C_AUTHZ_NONE,
            &sqos);
  if (s)
    _err(L"RpcBindingSetAuthInfoEx", s);

  long sum = 0;
  __try {
    sum = Add(h, a, b); // here's the actual RPC
  }
  __except(EXCEPTION_EXECUTE_HANDLER) {
    _err(L"RPC", GetExceptionCode());
  }
  RpcBindingFree(&h);
  return sum;
}

#ifdef ACT_AS_RPC_SERVER
void _listenForRPCRequests() {
  // register our RpcCalc interface with the RPC runtime
  RPC_STATUS s = RpcServerRegisterIf(
                    RpcCalc_v1_0_s_ifspec, 0, 0);
  
  // choose TCP as our network transport
  s = RpcServerUseProtseq(L"ncacn_ip_tcp",
                    RPC_C_PROTSEQ_MAX_REQS_DEFAULT, 0);
  if (s)
    _err(L"RpcServerUseProtseq", s);

  // see which TCP port we were allocated
  RPC_BINDING_VECTOR* pbv;
  s = RpcServerInqBindings(&pbv);
  if (s)
    _err(L"RpcServerInqBindings", s);

  // register protseq, port, and IID
  // with the endpoint mapper
  s = RpcEpRegister(RpcCalc_v1_0_s_ifspec, pbv, 0, 0);
  if (s)
    _err(L"RpcEpRegister", s);

  // choose the Kerberos SSP
  s = RpcServerRegisterAuthInfo(0,
        RPC_C_AUTHN_GSS_KERBEROS, 0, 0);
  if (s)
    _err(L"RpcServerRegisterAuthInfo", s);

  // turn on the fire hose!
  s = RpcServerListen(0, RPC_C_LISTEN_MAX_CALLS_DEFAULT,
                      FALSE);
  if (s)
    _err(L"RpcServerListen", s);
}

long Add(RPC_BINDING_HANDLE h, long a, long b) {

  // server detects the client's authn settings
  RPC_AUTHZ_HANDLE hPrivs;
  DWORD nAuthnLevel;
  RPC_STATUS s = RpcBindingInqAuthClient(h,
                    &hPrivs, 0, &nAuthnLevel, 0, 0);

  // don't allow anonymous callers through
  if (s)
    RpcRaiseException(ERROR_ACCESS_DENIED);

  // make sure we're happy with the caller's authn level
  if (nAuthnLevel < RPC_C_AUTHN_LEVEL_PKT_INTEGRITY)
    RpcRaiseException(ERROR_ACCESS_DENIED);

  // here's a really low tech auditing mechanism ;-)
  wprintf(L"Add invoked by %s\n", (wchar_t*)hPrivs);

  return a + b;
}
#endif
