// LogonSessions.cpp
#include "stdafx.h"

// interface dependencies
#include "LogonSessions.h"

// implementation dependencies
#include "Principals.h"
#include "stdio.h"
#pragma comment( lib, "rpcrt4.lib" )

static void CodeSnippet1() {
HANDLE htok;
OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY,
                 &htok);
// do something with the token,
// then close it when you're done
CloseHandle(htok);
}

static void CodeSnippet2() {
wchar_t szPassword[80];
_readSecret(L"MyDaemonSecret", szPassword,
            sizeof szPassword / sizeof *szPassword);
HANDLE hfile = _openFileAsUser2(L"MyDomain",
                       L"MyDaemonAccount",
                       szPassword,
                       L"\\\\machine\\share\\foo.txt",
                       GENERIC_READ);
}

// psuedocode snippet
HANDLE _GetClientTokenFromPipeObject(HANDLE hpipe) {
  // this is just for exposition, 
  // how the OS implements this isn't documented.
  return 0;
}

void _printTokenGroups(HANDLE htok) {
  // the first call discovers how much memory we need
  DWORD cbInfo = 0;
  if (!GetTokenInformation(htok, TokenGroups,
                           0, 0, &cbInfo) &&
        ERROR_INSUFFICIENT_BUFFER == GetLastError()) {

    // use whatever memory allocation scheme you like
    TOKEN_GROUPS* ptg =
        (TOKEN_GROUPS*) malloc(cbInfo);

    // call the function a second time to get an answer
    if (GetTokenInformation(htok, TokenGroups,
                            ptg, cbInfo, &cbInfo)) {

      // print each group SID
      for (DWORD i = 0; i < ptg->GroupCount; ++i) {
        _printSid(ptg->Groups[i].Sid);
        wprintf(L"\n");
      }
    }

    // clean up
    free(ptg);
  }
}

bool _isAdministrator(HANDLE htok) {

  bool bIsAdmin = false;

  // the first call discovers how much memory we need
  DWORD cbInfo = 0;
  if (!GetTokenInformation(htok, TokenGroups,
                           0, 0, &cbInfo) &&
        ERROR_INSUFFICIENT_BUFFER == GetLastError()) {

    // use whatever memory allocation scheme you like
    TOKEN_GROUPS* ptg =
        (TOKEN_GROUPS*) malloc(cbInfo);

    // call the function a second time to get an answer
    if (GetTokenInformation(htok, TokenGroups,
                              ptg, cbInfo, &cbInfo)) {

      // print each group SID
      for (DWORD i = 0; i < ptg->GroupCount; ++i) {
        if (_isAdministratorSid(ptg->Groups[i].Sid)) {
          bIsAdmin = true;
          break;
        }
      }
    }

    // clean up
    free(ptg);
  }
  return bIsAdmin;
}

bool _enablePrivilege(HANDLE htok,
                      const wchar_t* pszPriv,
                      bool bEnable,
                      TOKEN_PRIVILEGES& tpOld) {
  // fill out the request form :-)
  TOKEN_PRIVILEGES tp;
  tp.PrivilegeCount = 1;
  tp.Privileges[0].Attributes =
                     bEnable ? SE_PRIVILEGE_ENABLED : 0;
  if (!LookupPrivilegeValue(0, pszPriv,
                            &tp.Privileges[0].Luid))
    return false;
  
  // htok must have been opened with these permissions:
  // TOKEN_QUERY (to get the old priv setting)
  // TOKEN_ADJUST_PRIVILEGES (to adjust the priv)
  DWORD cbOld = sizeof tpOld;
  if (!AdjustTokenPrivileges(htok, FALSE, &tp,
                             cbOld, &tpOld, &cbOld))
    return false;
  
  // Check GetLastError() to see if the privilege was
  // successfully adjusted - don't forget this step!
  return (ERROR_NOT_ALL_ASSIGNED != GetLastError());
}

void _restorePrivilege(HANDLE htok,
                       TOKEN_PRIVILEGES& tpOld) {
  AdjustTokenPrivileges(htok, FALSE, &tpOld, 0, 0, 0);
}

void _dumpFile(HANDLE hfile) {
  // brain-dead print routine for brevity
  DWORD cb = GetFileSize(hfile, 0);
  void* p = malloc(cb);
  ReadFile(hfile, p, cb, &cb, 0);
  WriteFile(GetStdHandle(STD_OUTPUT_HANDLE), p, cb, &cb, 0);
  free(p);
}

void _backupFile(const wchar_t* pszFile) {
  // open token with permissions needed to adjust privs
  HANDLE htok;
  OpenProcessToken(GetCurrentProcess(),
            TOKEN_QUERY | TOKEN_ADJUST_PRIVILEGES,
            &htok);

  // enable SeBackupPrivilege
  TOKEN_PRIVILEGES tpOld;
    if (_enablePrivilege(htok, SE_BACKUP_NAME,
                         true, tpOld)) {

    // open the file with the intention of backing it up
    HANDLE hfile = CreateFile(pszFile, GENERIC_READ,
                      0, 0,
                      OPEN_EXISTING,
                      FILE_FLAG_BACKUP_SEMANTICS, 0);
    if (INVALID_HANDLE_VALUE != hfile) {
      _dumpFile(hfile);
      CloseHandle(hfile);
    }

    // clean up when we're done
    _restorePrivilege(htok, tpOld);
  }
  else wprintf(L"Failed to enable SeBackupPrivilege"
               L" - do you have this privilege?\n");
  CloseHandle(htok);  
}

DWORD WINAPI _threadProc1(void*) {
  HANDLE htok;
  OpenProcessToken(GetCurrentProcess(),
                   TOKEN_IMPERSONATE, &htok);
  // the goal is to give this thread its own token
  // but does this really do the job?
  SetThreadToken(0, htok);

  // do work (adjust privileges, etc.)
  
  // by removing the thread token, we revert
  // back to the process's security context
  SetThreadToken(0, 0);
  return 0;
}

DWORD WINAPI _threadProc2(void*) {
  HANDLE htok;
  OpenProcessToken(GetCurrentProcess(),
                   TOKEN_DUPLICATE, &htok);
  // the goal is to give this thread its own token
  // so let's duplicate the object and make it happen
  HANDLE htokForMyThread;
  DuplicateTokenEx(htok, TOKEN_ALL_ACCESS, 0,
        DEFAULT_IMPERSONATION_LEVEL,
        TokenImpersonation, // ask for a thread token
        &htokForMyThread);
                   
  SetThreadToken(0, htokForMyThread);

  // do work (adjust privileges, etc.)

  // when finished messing with the token handle, we can
  // close it anytime; the thread still references it
  CloseHandle(htokForMyThread);

  // by removing the thread token, we revert
  // back to the process's security context;
  // note that this also destroys the token we created
  // because the thread no longer references its handle
  SetThreadToken(0, 0);
  return 0;
}

DWORD WINAPI _threadProc3(void*) {
  ImpersonateSelf(SecurityImpersonation);

  // do work (adjust privileges, etc.)

  RevertToSelf();
  return 0;
}

HANDLE _openFileAsUser1(wchar_t* pszAuthority,
                        wchar_t* pszPrincipal,
                        wchar_t* pszPassword,
                        wchar_t* pszFile,
                        DWORD dwDesiredAccess) {
  // attempt to establish a batch style logon session
  // for the specified principal
  HANDLE htok;
  if (!LogonUser(pszPrincipal, pszAuthority,
                 pszPassword,
                 LOGON32_LOGON_BATCH, 0, &htok))
    return INVALID_HANDLE_VALUE;

  // put the token on our thread (does this work?)
  if (!SetThreadToken(0, htok))
    return INVALID_HANDLE_VALUE;

  // open the remote file
  HANDLE hfile = CreateFile(pszFile, dwDesiredAccess,
                            0, 0, OPEN_EXISTING, 0, 0);

  // remove the token from our thread
  SetThreadToken(0, 0);
  
  CloseHandle(htok);
  return hfile;
}


HANDLE _openFileAsUser2(wchar_t* pszAuthority,
                        wchar_t* pszPrincipal,
                        wchar_t* pszPassword,
                        wchar_t* pszFile,
                        DWORD dwDesiredAccess) {
  // attempt to establish a batch logon session
  // for the specified principal
  HANDLE htok;
  if (!LogonUser(pszPrincipal, pszAuthority,
                 pszPassword,
                 LOGON32_LOGON_BATCH, 0, &htok))
    return INVALID_HANDLE_VALUE;

  // put the token on our thread (this works!)
  ImpersonateLoggedOnUser(htok);

  // open the remote file
  HANDLE hfile = CreateFile(pszFile, dwDesiredAccess,
                            0, 0, OPEN_EXISTING, 0, 0);

  // stop impersonating
  RevertToSelf();
  
  CloseHandle(htok);
  return hfile;
}

HANDLE _getEffectiveToken(DWORD dwDesiredAccess,
                           BOOL bWantImpToken,
   SECURITY_IMPERSONATION_LEVEL impLevel) {
    HANDLE htok;
    if (OpenThreadToken(GetCurrentThread(),
        dwDesiredAccess, TRUE, &htok))
        return htok;
    else if (ERROR_NO_TOKEN == GetLastError()) {
        DWORD grfAccess = bWantImpToken ? TOKEN_DUPLICATE :
                                          dwDesiredAccess;
        if (OpenProcessToken(GetCurrentProcess(),
            grfAccess, &htok)) {
            if (bWantImpToken) {
                // convert primary to impersonation token
                HANDLE htokImp;
                if (!DuplicateTokenEx(htok, dwDesiredAccess, 0,
                      impLevel, TokenImpersonation, &htokImp)) {
                    htokImp = 0;
                }
                CloseHandle(htok);
                return htokImp;
            }
            else return htok;
        }
    }
    return 0;
}

HANDLE _getClientToken() {
  CoImpersonateClient();
  HANDLE htok;
  OpenThreadToken(GetCurrentThread(), TOKEN_QUERY,
                  TRUE, &htok);
  CoRevertToSelf();
  return htok;
}
