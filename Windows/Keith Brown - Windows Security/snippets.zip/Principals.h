// Principals.h
#pragma once

// you can't use this version to alloc byte arrays on the stack
//const DWORD _maxSidSize = GetSidLengthRequired(SID_MAX_SUB_AUTHORITIES);

// you *can* use this version to alloc byte arrays on the stack
const DWORD _maxSidSize = sizeof(SID) + sizeof(DWORD) * (SID_MAX_SUB_AUTHORITIES - 1);

// helper for efficiently constructing well-known SIDs
struct SIDWithTwoSubauthorities {
	SID   base;
	DWORD subAuth;
};

void _lookupErrorMsg(wchar_t* pszMsg, int cch, DWORD err = GetLastError());
int _err(const wchar_t* pszFcn, DWORD err = GetLastError(), bool bHalt = true);
int _lsaErr(const wchar_t* pszFcn, NTSTATUS err, bool bHalt = true);
void _initString(UNICODE_STRING& us, wchar_t* psz);
void _initString(LSA_STRING& s, char* psz);
void _printSid(void* psid);
bool _isAdministratorSid(void* psid);
void _readSecret(wchar_t* pszKey, wchar_t* pszValue, DWORD cchValue);
DWORD _grantPrivilege(wchar_t* pszMachine,
                      void* psid,
                      wchar_t* pszPrivilege);

