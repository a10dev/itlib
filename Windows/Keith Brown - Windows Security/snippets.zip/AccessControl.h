// AccessControl.h
#pragma once

#include "Principals.h"

const DWORD _maxVersion2AceSize =
  sizeof(ACCESS_ALLOWED_ACE) - sizeof(DWORD)
                             + _maxSidSize;

void _dumpDacl(ACL* pdacl);
ACL* _insertAccessAllowedAce(ACL* pacl,
                             DWORD grfMask,
                             DWORD grfInherit,
                             PSID psid);
ACL* _insertAccessDeniedAce(ACL* pacl,
                            DWORD grfMask,
                            DWORD grfInherit,
                            PSID psid);
#if _WIN32_WINNT < 0x500
BOOL AddAccessAllowedAceEx(PACL pAcl, DWORD dwAceRevision, DWORD AceFlags, DWORD AccessMask, PSID pSid);
BOOL AddAccessDeniedAceEx(PACL pAcl, DWORD dwAceRevision, DWORD AceFlags, DWORD AccessMask, PSID pSid);
#endif
