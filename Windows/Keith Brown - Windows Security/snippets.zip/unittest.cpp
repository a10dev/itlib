// unittest.cpp
#include "stdafx.h"

// interface dependencies
#include "unittest.h"

// implementation dependencies
#include <stdio.h>
#include <conio.h>

//#define WAIT_FOR_KEYPRESS

__declspec(thread) bool tls_bInteractive = false;

void BeginTest( const wchar_t* psz, bool bInteractive ) {
  tls_bInteractive = bInteractive;
	wprintf( L"*** Testing %s ***\n", psz );
}

void EndTest() {
  if ( tls_bInteractive ) {
#if defined(WAIT_FOR_KEYPRESS)
    wprintf( L"Press any key to continue...\n\n" );
		getch();
#endif // WAIT_FOR_KEYPRESS
  }
  wprintf( L"*** End Test ***\n\n" );
}
