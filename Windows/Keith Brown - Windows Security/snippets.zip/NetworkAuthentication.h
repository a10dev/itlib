// NetworkAuthentication.h
#pragma once

void _purgeTicketCache();
