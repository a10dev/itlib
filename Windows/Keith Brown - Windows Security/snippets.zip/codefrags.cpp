// codefrags.cpp
#include "stdafx.h"

#include "LogonSessions.h"
#include "WindowStations.h"
#include "AccessControl.h"
#include "NetworkAuthentication.h"
#include "FileServer.h"
#include "COM.h"
#include "Principals.h"

#include "unittest.h"
#include <stdio.h>
#include <userenv.h>
#define SECURITY_WIN32
#include <security.h>
#include <ntsecapi.h>

void UnitTestPrincipals() {
  BeginTest( L"_grantPrivilege", true );
  wchar_t szAuthority[256];
  DWORD cchAuthority = sizeof szAuthority / sizeof *szAuthority;
  SID_NAME_USE snu;
  BYTE sidBob[_maxSidSize];
  DWORD cbSid = sizeof sidBob;
  LookupAccountName(0, L"Bob", sidBob, &cbSid,
                    szAuthority, &cchAuthority, &snu);
  DWORD err = _grantPrivilege(0, sidBob, SE_BATCH_LOGON_NAME);
  if (err)
       wprintf(L"Failed.");
  else wprintf(L"Succeeded.");
  EndTest();
}

void UnitTestLogonSessions() {
  HANDLE htok;
  OpenProcessToken( GetCurrentProcess(), TOKEN_QUERY, &htok );

  BeginTest( L"_printTokenGroups", true );
  _printTokenGroups( htok );
  EndTest();
    
  BeginTest( L"_isAdministrator", true );
  if ( _isAdministrator( htok ) )
       wprintf( L"You are an administrator on this machine.\n" );
  else wprintf( L"You are not an administrator on this machine.\n" );
  EndTest();
  
  BeginTest( L"_backupFile", true );
  _backupFile( L"d:\\test.txt" );
  wprintf( L"\n" );
  EndTest();

  BeginTest( L"_threadProcA", false );
  // should fail miserably
  _threadProc1( 0 );
  wprintf( L"Test succeeded.\n" );
  EndTest();

  BeginTest( L"_threadProcB", false );
  _threadProc2( 0 );
  wprintf( L"Test succeeded.\n" );
  EndTest();

  BeginTest( L"_openFileAsUser1", false );
  // first one should fail miserably
  if ( INVALID_HANDLE_VALUE ==
    _openFileAsUser1( L".", L"alice", L"alice", L"\\\\wendoline\\c\\test.txt", GENERIC_READ ) )
       wprintf( L"Test succeeded.\n" );
  else wprintf( L"Test failed.\n" );

  EndTest();

  BeginTest( L"_openFileAsUser2", false );
  // this one should succeed
  {
  HANDLE h =
  _openFileAsUser2( L".", L"alice", L"alice", L"\\\\wendoline\\c\\test.txt", GENERIC_READ );
  if ( INVALID_HANDLE_VALUE == h )
       wprintf( L"Test failed.\n" );
  else wprintf( L"Test succeeded.\n" );
  CloseHandle( h );
  }
  EndTest();

  CloseHandle( htok );
}

void UnitTestWindowStations() {

  BeginTest( L"_listWindowStations", true );
  _listWindowStations();
  EndTest();

  BeginTest( L"_switchToDesktop", true );
  {
  const wchar_t* pszDesk = L"foo";
  bool bOk = false;
  HDESK hd = CreateDesktop( pszDesk, 0, 0, 0, DESKTOP_CREATEWINDOW | DESKTOP_SWITCHDESKTOP, 0 );
  if ( hd )
  {
    if ( _switchToDesktop( pszDesk ) )
    {
      Sleep( 1000 );
      bOk = _switchToDesktop( L"Default" );
    }
    CloseDesktop( hd );
  }
  if ( bOk )
       wprintf( L"Test succeeded.\n" );
  else wprintf( L"Test failed.\n" );
  }
  EndTest();

  BeginTest( L"_baitAndSwitchDesktop", true );
  _baitAndSwitchDesktop();
  EndTest();

  BeginTest(L"_startDaemonAsUser", true);
  {
  const bool bOk = _startDaemonAsUser(L".", L"alice", L"alice", L"notepad");
  if ( bOk )
       wprintf( L"Test succeeded.\n" );
  else wprintf( L"Test failed.\n" );
  }
  EndTest();  

  BeginTest(L"_loadUserProfile", true);
  {
    bool bOk = false;
    HANDLE htok;
    if (LogonUser(L"alice", L".", L"alice", LOGON32_LOGON_INTERACTIVE, 0, &htok)) {
      HANDLE hprof;
      bOk = _loadUserProfile(htok, hprof);
      if ( bOk ) {
        UnloadUserProfile(htok, hprof);
        wprintf( L"Test succeeded.\n" );
      }
      else wprintf( L"Test failed.\n" );
      CloseHandle(htok);
    }
  }
  EndTest();  

  BeginTest(L"_runAsUser", true);
  {
  const bool bOk = _runAsUser(L".", L"alice", L"alice", L"notepad");
  if ( bOk )
       wprintf( L"Test succeeded.\n" );
  else wprintf( L"Test failed.\n" );
  }
  EndTest();  
}

void UnitTestAccessControl() {
  BeginTest(L"_dumpDacl", true);
  {
    void* psd;
    ACL* pdacl;
    GetNamedSecurityInfo(L"MACHINE\\Software\\Test", SE_REGISTRY_KEY,
      DACL_SECURITY_INFORMATION, 0, 0, &pdacl, 0, &psd);
    _dumpDacl(pdacl);
  }
  EndTest();  

  BeginTest(L"_insertAccessAllowedAce and _insertAccessDeniedAce", true);
  {
    void* psd;
    ACL* pdacl;
    GetNamedSecurityInfo(L"MACHINE\\Software\\Test", SE_REGISTRY_KEY,
      DACL_SECURITY_INFORMATION, 0, 0, &pdacl, 0, &psd);
    _dumpDacl(pdacl);

    wprintf(L"\nAdding an Access Allowed ACE...\n\n");    

    SID batchSID = {SID_REVISION, 1, SECURITY_NT_AUTHORITY, SECURITY_BATCH_RID};
    ACL* pdacl2 = _insertAccessAllowedAce(pdacl, 0x1, 0, &batchSID);
    _dumpDacl(pdacl2);

    wprintf(L"\nAdding an Access Denied ACE...\n\n");    
    
    ACL* pdacl3 = _insertAccessDeniedAce(pdacl2, 0x2, 0, &batchSID);
    _dumpDacl(pdacl3);

    LocalFree(pdacl3);
    LocalFree(pdacl2);
    LocalFree(psd);
  }
  EndTest();  

  BeginTest(L"CodeSnippet11", true);
  extern void CodeSnippet11();
  CodeSnippet11();
  EndTest();  
}

void UnitTestNetworkAuthentication() {
#if _WIN32_WINNT >= 0x500
  BeginTest(L"_purgeTicketCache", true);
  _purgeTicketCache();
  EndTest();
#endif
}

void UnitTestFileServer() {
/*
  BeginTest(L"_establishNullSession", true);
  _establishNullSession(L"\\\\shawn");
  EndTest();

  BeginTest(L"_enumAllSessions", true);
  _enumAllSessions(L"\\\\shawn");
  EndTest();
*/

  BeginTest(L"_establishUseRecord", true);
  {
    // establish use records and bump up their reference counts a bit
    for (int i = 0; i < 3; ++i) {
      _establishUseRecord(L"\\\\wendoline\\ipc$", L"quux", L"qu", L"guest");
      _establishUseRecord(L"\\\\shawn\\ipc$", L"shawn", L"alice", L"alice");
    }
  }
  EndTest();

  BeginTest(L"_enumUseRecords", true);
  _enumUseRecords();
  EndTest();

  BeginTest(L"_removeUseRecord", true);
  _removeUseRecord(L"\\\\wendoline\\ipc$");
  _removeUseRecord(L"\\\\shawn\\ipc$");
  EndTest();
}

void UnitTestCOM() {
  BeginTest(L"_addViaRPC", true);
  _addViaRPC(2, 2, L"ncacn_ip_tcp:preston", L"foo\\alice");
  EndTest();
}

void main() {
#ifdef ACT_AS_RPC_SERVER
  _listenForRPCRequests();
#else
  UnitTestPrincipals();
//  UnitTestLogonSessions();
//  UnitTestWindowStations();
//  UnitTestAccessControl();
//  UnitTestNetworkAuthentication();
//  UnitTestFileServer();
//  UnitTestCOM();
#endif
}
