// FileServer.cpp
#include "stdafx.h"

// interface dependencies
#include "FileServer.h"

// implementation dependencies
#include "Principals.h"
#include <stdio.h>
#include <lm.h>
#pragma comment(lib, "netapi32.lib")
#pragma comment(lib, "mpr.lib")

void _enumAllSessions(wchar_t* pszServer) {
  SESSION_INFO_10* prgInfo;
  DWORD cRead, cTotal;
  NET_API_STATUS s = NetSessionEnum(pszServer, 0, 0,
                          10, (BYTE**)&prgInfo,
                          MAX_PREFERRED_LENGTH,
                          &cRead, &cTotal, 0);
  if (s)
    _err(L"NetSessionEnum", s);

  for (DWORD i = 0; i < cRead; ++i) {
    SESSION_INFO_10& info = prgInfo[i];
    wprintf(L"Client Host:      %s\n",
            info.sesi10_cname);
    wprintf(L"Client Principal: %s\n",
            info.sesi10_username);
    wprintf(L"Session started %d sec ago\n",
            info.sesi10_time);
    wprintf(L"Session has been idle for %d sec\n\n",
            info.sesi10_idle_time);
  }

  // standard cleanup for Lan Manager APIs
  NetApiBufferFree(prgInfo);
}

void _establishNullSession(wchar_t* pszServer) {
  NETRESOURCE nr;
  ZeroMemory(&nr, sizeof nr);
  nr.dwType       = RESOURCETYPE_ANY;
  nr.lpRemoteName = pszServer;

  DWORD err = WNetAddConnection2(&nr, L"", L"", 0);
  if (err)
    _err(L"WNetAddConnection2", err);
}

void _establishUseRecord( wchar_t* pszResource,
                          wchar_t* pszAuthority,
                          wchar_t* pszPrincipal,
                          wchar_t* pszPassword) {
  USE_INFO_2 ui2;
  ZeroMemory(&ui2, sizeof ui2);

  // NetUseAdd obfuscates and then rehydrates the
  // data that ui2_password points to for some reason,
  // so be sure to pass a writable pointer!
  wchar_t szPassword[80];
  lstrcpy(szPassword, pszPassword);

  ui2.ui2_remote     = pszResource;
  ui2.ui2_domainname = pszAuthority;
  ui2.ui2_username   = pszPrincipal;
  ui2.ui2_password   = szPassword;
  ui2.ui2_asg_type   = USE_WILDCARD;
  
  DWORD nParmErr;
  NET_API_STATUS s = NetUseAdd(0, 2,
                     (BYTE*)&ui2, &nParmErr);
  if (s)
    _err(L"NetUseAdd", s);
}

void _removeUseRecord(wchar_t* pszResource) {
  NET_API_STATUS s = NetUseDel(0, pszResource,
                               USE_FORCE);
  if (s)
    _err(L"NetUseDel", s);
}

void _enumUseRecords() {
  USE_INFO_2* prgui;
  DWORD cRead, cTotal;
  NET_API_STATUS s = NetUseEnum(0, 2, (BYTE**)&prgui,
                                MAX_PREFERRED_LENGTH,
                                &cRead, &cTotal, 0);
  if (s)
    _err(L"NetUseEnum", s);
  for (DWORD i = 0; i < cRead; ++i) {
    USE_INFO_2& ui = prgui[i];
    wprintf(L"Resource:      %s\n", ui.ui2_remote);
    wprintf(L"Local Mapping: %s\n", ui.ui2_local);
    wprintf(L"Status:        %d\n", ui.ui2_status);
    wprintf(L"Type:          %d\n", ui.ui2_asg_type);
    wprintf(L"Ref Count:     %d\n", ui.ui2_usecount);
    wprintf(L"Authority:     %s\n", ui.ui2_domainname);
    wprintf(L"Principal:     %s\n", ui.ui2_username);
    wprintf(L"\n");
  }
  NetApiBufferFree(prgui);
}
