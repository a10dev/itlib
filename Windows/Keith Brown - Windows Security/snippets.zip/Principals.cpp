// Principals.cpp
#include "stdafx.h"

// interface dependencies

// implementation dependencies
#include "Principals.h"
#include <stdio.h>
#include <lmerr.h>

void _lookupErrorMsg(wchar_t* pszMsg, int cch, DWORD err) {

  DWORD grfFormat = FORMAT_MESSAGE_FROM_SYSTEM |
                    FORMAT_MESSAGE_IGNORE_INSERTS;

  HMODULE hdll = 0;
  if (err >= NERR_BASE && err <= MAX_NERR) {
    hdll = LoadLibraryEx(L"netmsg.dll", 0,
                         LOAD_LIBRARY_AS_DATAFILE);
  }

  if (hdll)
    grfFormat |= FORMAT_MESSAGE_FROM_HMODULE;

  if (!FormatMessage(grfFormat, hdll, err, 0,
                     pszMsg, cch, 0))
    wsprintf(pszMsg, L"Unknown Error: %d (0x%08X)", err, err);

  if (hdll)
    FreeLibrary(hdll);
}

int _err(const wchar_t* pszFcn, DWORD err, bool bHalt) {
  wchar_t szMsg[512];
  _lookupErrorMsg(szMsg, sizeof szMsg / sizeof *szMsg, err);
  
  wprintf(L"%s failed: %s", pszFcn, szMsg);
  
  if (bHalt)
    Sleep(INFINITE);
  
  return err;
}

int _lsaErr(const wchar_t* pszFcn, NTSTATUS err, bool bHalt) {
  return _err(pszFcn, LsaNtStatusToWinError(err), bHalt);
}

void _initString(UNICODE_STRING& us, wchar_t* psz) {
  USHORT cch = wcslen(psz);
  us.Length = cch * sizeof(wchar_t);
  us.MaximumLength = (cch + 1) * sizeof(wchar_t);
  us.Buffer = psz;
}

void _initString(LSA_STRING& s, char* psz) {
  USHORT cch = lstrlenA(psz);
  s.Length = cch;
  s.MaximumLength = cch + 1;
  s.Buffer = psz;
}

void _printSid( void* psid ) {

	// formatting algorithm borrowed from mssdk
	// sample "textsid", by Scott Field
	const SID_IDENTIFIER_AUTHORITY& ia =
		*GetSidIdentifierAuthority( psid );
	wchar_t szIdentifierAuthority[20];

	if ( !ia.Value[0] && !ia.Value[1] ) {
		// decimal form
		wsprintf(	szIdentifierAuthority, L"%u", 
							static_cast<ULONG>(ia.Value[5]      ) +
							static_cast<ULONG>(ia.Value[4] <<  8) +
							static_cast<ULONG>(ia.Value[3] << 16) +
							static_cast<ULONG>(ia.Value[2] << 24) );
	}
	else {
		// hex form
		wsprintf(	szIdentifierAuthority,
							L"0x%02hx%02hx%02hx%02hx%02hx%02hx", 
              static_cast<USHORT>(ia.Value[0]),
              static_cast<USHORT>(ia.Value[1]),
              static_cast<USHORT>(ia.Value[2]),
              static_cast<USHORT>(ia.Value[3]),
              static_cast<USHORT>(ia.Value[4]),
              static_cast<USHORT>(ia.Value[5]) );
	}

	// S-R-IA
	wprintf( L"S-%d-%s", int( reinterpret_cast<SID*>(psid)->Revision ),
	                     szIdentifierAuthority );

	//       -SA-SA-SA-SA
	const int nSubAuthorities = *GetSidSubAuthorityCount( psid );
	for ( int i = 0; i < nSubAuthorities; ++i )
		wprintf( L"-%d", int( *GetSidSubAuthority( psid, i ) ) );
}

bool _isAdministratorSid( void* psid )
{
	static SIDWithTwoSubauthorities sid = {
	    SID_REVISION, 2,
		SECURITY_NT_AUTHORITY,
		SECURITY_BUILTIN_DOMAIN_RID,
		DOMAIN_ALIAS_RID_ADMINS
	};
	return EqualSid( &sid, psid ) ? true : false;
}

DWORD _grantPrivilege(wchar_t* pszMachine,
                      void* psid,
                      wchar_t* pszPrivilege) {
    LSA_UNICODE_STRING usMachine, usPrivilege;
    if (pszMachine)
        _initString(usMachine, pszMachine);
    _initString(usPrivilege, pszPrivilege);

    LSA_OBJECT_ATTRIBUTES oa = {sizeof oa};
    DWORD grfAccess = POLICY_LOOKUP_NAMES |
                      POLICY_CREATE_ACCOUNT;
    LSA_HANDLE hPolicy;
    NTSTATUS s = LsaOpenPolicy(pszMachine ?
                               &usMachine: 0,
                               &oa, grfAccess,
                               &hPolicy);
    if (!s) {
        s = LsaAddAccountRights(hPolicy, psid,
                                &usPrivilege, 1);
        LsaClose(hPolicy);
    }
    return LsaNtStatusToWinError(s);
}