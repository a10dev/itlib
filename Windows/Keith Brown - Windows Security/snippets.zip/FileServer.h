// FileServer.h
#pragma once

void _enumAllSessions(wchar_t* pszServer);
void _establishNullSession(wchar_t* pszServer);
void _establishUseRecord(wchar_t* pszResource,
                        wchar_t* pszAuthority,
                        wchar_t* pszPrincipal,
                        wchar_t* pszPassword);
void _removeUseRecord(wchar_t* pszResource);
void _enumUseRecords();
