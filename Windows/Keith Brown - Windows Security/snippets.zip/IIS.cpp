// COM.cpp
#include "stdafx.h"

// interface dependencies

// implementation dependencies

struct Foo {
  HRESULT DoSomethingPowerful();
};

HRESULT Foo::DoSomethingPowerful() {
  HANDLE htok;
  OpenThreadToken(GetCurrentThread(),
                  TOKEN_IMPERSONATE,
                  TRUE, &htok);
  RevertToSelf();
  // we're now executing in the TCB!
  SetThreadToken(0, htok);
  CloseHandle(htok);
  return S_OK;
}
