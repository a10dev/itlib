// WindowStations.h
#pragma once

void _makeAssertSafeForDaemons();
int _crtDbgReportHook( int   reportType,
                       char* message,
                       int*  returnValue );
void _listWindowStations();
bool _switchToDesktop( const wchar_t* pszDesk );
void _baitAndSwitchDesktop();
bool _startDaemonAsUser(
    wchar_t* pszAuthority,
    wchar_t* pszPrincipal,
    wchar_t* pszPassword,
    wchar_t* pszCommandLine);
bool _loadUserProfile(HANDLE htok, HANDLE& hprof);
bool _runAsUser(
    wchar_t* pszAuthority,
    wchar_t* pszPrincipal,
    wchar_t* pszPassword,
    wchar_t* pszCommandLine);
