// LogonSessions.cpp
#include "stdafx.h"

// interface dependencies
#include "WindowStations.h"

// implementation dependencies
#include <crtdbg.h>
#include <userenv.h>
#pragma comment(lib, "userenv.lib")

static void CodeSnippet1() {
CloseHandle(GetProcessWindowStation()); // whoops!
}

static void CodeSnippet2() {
// safe, actually does nothing
CloseWindowStation(GetProcessWindowStation());
}

static void CodeSnippet3() {
HWINSTA h1, h2;
h1 = CreateWindowStation(L"Foo", 0, READ_CONTROL, 0);
h2 = CreateWindowStation(L"Bar", 0, READ_CONTROL, 0);
}

static void CodeSnippet4() {
HWINSTA h1, h2;
h1 = CreateWindowStation(0, 0, READ_CONTROL, 0);
h2 = CreateWindowStation(0, 0, READ_CONTROL, 0);
}

static void CodeSnippet5() {
HWINSTA hwsOld    = GetProcessWindowStation();
HWINSTA hwsTarget = OpenWindowStation(L"Winsta0",
                                 FALSE, READ_CONTROL);
SetProcessWindowStation(hwsTarget); // do this first!
HDESK hdTarget = OpenDesktop(L"Default", 0, FALSE,
                             DESKTOP_SWITCHDESKTOP);
}

static void CodeSnippet6() {
  _startDaemonAsUser(L"foo",
                     L"alice",
                     L"password",
                     L"mydaemon");
}

void _makeAssertSafeForDaemons() {
  _CrtSetReportHook(_crtDbgReportHook);
}

// discussed in the documentation for _CrtSetReportHook,
// this function is called whenever an assertion fires
int _crtDbgReportHook(int   reportType,
                      char* message,
                      int*  returnValue) {
  if (_CRT_ASSERT == reportType) {
    // here is the key piece of code
    switch (MessageBoxA(0, message, "SafeAssert",
                        MB_SERVICE_NOTIFICATION |
                        MB_ABORTRETRYIGNORE |
                        MB_ICONSTOP))
    {
      case IDABORT:
        ExitProcess(1);
        break;
      case IDRETRY:
        *returnValue = 1; // start debugger
        break;
      case IDIGNORE:
        *returnValue = 0; // continue execution
        break;
    }
    return 1; // no further reporting necessary
  }
  return 0;
}

BOOL CALLBACK _myWinstaEnumProc(wchar_t* pszName,
                                LPARAM lp) {
  // just append the name (and a newline) to the output
  wchar_t* pszOutput = (wchar_t*)lp;
  lstrcat(pszOutput, pszName);
  lstrcat(pszOutput, L"\n");

  return TRUE; // continue enumerating
}

void _listWindowStations() {
  
  // I'm punting on buffer management for simplicity
  wchar_t szOutput[4096];
  szOutput[0] = L'\0';

  // tell the system to call _myWinstaEnumProc once
  // for each window station that we are allowed to see
  EnumWindowStations(_myWinstaEnumProc,
                     (LPARAM)szOutput);
  
  MessageBox(0, szOutput, L"Window Station List",
             MB_SETFOREGROUND | MB_ICONINFORMATION);
}

bool _switchToDesktop(const wchar_t* pszDesk) {

  // open the specified desktop
  // with the intention of switching
  bool bSucceeded = false;
  HDESK hd = OpenDesktop(pszDesk, 0, 0,
                         DESKTOP_SWITCHDESKTOP);
  // do the switch
  if ( hd ) {
    if (SwitchDesktop(hd))
      bSucceeded = true;

    CloseDesktop(hd);
  }
  return bSucceeded;
}

void _baitAndSwitchDesktop() {
  
  // first remember the old desktop
  // so we can switch back
  HDESK hdOld =
    GetThreadDesktop(GetCurrentThreadId());

  // create a desktop (assuming it doesn't already
  // exist), with the intention of switching to it
  const DWORD grfAccess = DESKTOP_CREATEWINDOW |
                          DESKTOP_SWITCHDESKTOP;
  HDESK hdNew = CreateDesktop(L"Foo", 0, 0, 0,
                              grfAccess, 0);
  if (hdNew) {
    
    // migrate our thread to the Foo desktop
    // and make it the active desktop
    SetThreadDesktop(hdNew);
    SwitchDesktop   (hdNew);

    // display a stunning user interface
    MessageBox(0, L"Hello World!", L"Foo Desktop", 0);

    // switch back
    SwitchDesktop   (hdOld);
    SetThreadDesktop(hdOld);

    // since this is the last reference to the
    // desktop Foo, the operating system destroys it
    CloseDesktop(hdNew);
  }
  CloseDesktop(hdOld);
}

bool _startDaemonAsUser(
    wchar_t* pszAuthority,
    wchar_t* pszPrincipal,
    wchar_t* pszPassword,
    wchar_t* pszCommandLine) {

  HANDLE htok;
  BOOL bOk = LogonUser(pszPrincipal,
                       pszAuthority,
                       pszPassword,
                       LOGON32_LOGON_BATCH, 0,
                       &htok);
  if (bOk) {
    STARTUPINFO si = { sizeof si, 0, L"" };
    PROCESS_INFORMATION pi;
    wchar_t szCmd[MAX_PATH];
    lstrcpy(szCmd, pszCommandLine);
    bOk = CreateProcessAsUser(htok,
                              0, szCmd,
                              0, 0,
                              FALSE, 0, 0, 0,
                              &si, &pi);
    if (bOk) {
      CloseHandle(pi.hThread);
      CloseHandle(pi.hProcess);
    }
  }
  return bOk ? true : false;
}

bool _loadUserProfile(HANDLE htok, HANDLE& hprof) {
  if (!ImpersonateLoggedOnUser(htok))
    return false;
  wchar_t szUserName[256];
  DWORD cch = sizeof szUserName / sizeof *szUserName;
  bool bOk = false;
  if (GetUserName(szUserName, &cch)) {
    RevertToSelf();
    PROFILEINFO pi = { sizeof pi, 0, szUserName };
    bOk = LoadUserProfile(htok, &pi) ? true : false;
    if (bOk)
      hprof = pi.hProfile;
  }
  return bOk;
}

bool _runAsUser(
    wchar_t* pszAuthority,
    wchar_t* pszPrincipal,
    wchar_t* pszPassword,
    wchar_t* pszCommandLine) {

  HANDLE htok;
  BOOL bOk = LogonUser(pszPrincipal,
                       pszAuthority,
                       pszPassword,
                       LOGON32_LOGON_BATCH, 0,
                       &htok);
  if (bOk) {
    HANDLE hprof = 0;
    bOk = _loadUserProfile(htok, hprof);
  }
  void* pEnv = 0;
  if (bOk) {
    bOk = CreateEnvironmentBlock(&pEnv, htok, FALSE);
    if (!bOk)
      pEnv = 0;
  }
  if (bOk) {
    STARTUPINFO si = { sizeof si, 0, L"" };
    PROCESS_INFORMATION pi;
    wchar_t szCmd[MAX_PATH];
    lstrcpy(szCmd, pszCommandLine);
    bOk = CreateProcessAsUser(htok,
            0, szCmd,
            0, 0,
            FALSE,
            CREATE_UNICODE_ENVIRONMENT, pEnv,
            0,
            &si, &pi);
    if (bOk) {
      CloseHandle(pi.hThread);
      CloseHandle(pi.hProcess);
    }
  }
  if (pEnv)
    DestroyEnvironmentBlock(pEnv);
  return bOk ? true : false;
}

