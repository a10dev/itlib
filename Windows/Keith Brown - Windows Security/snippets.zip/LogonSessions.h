// LogonSessions.h
#pragma once

void _printTokenGroups( HANDLE htok );
bool _isAdministrator( HANDLE htok );
bool _enablePrivilege( HANDLE htok, const wchar_t* pszPriv, bool bEnable, TOKEN_PRIVILEGES& tpOld );
void _restorePrivilege( HANDLE htok, const TOKEN_PRIVILEGES& tpOld );
void _backupFile( const wchar_t* pszFile );

DWORD WINAPI _threadProc1( void* );
DWORD WINAPI _threadProc2( void* );

HANDLE _openFileAsUser1( wchar_t* pszAuthority,
                         wchar_t* pszPrincipal,
                         wchar_t* pszPassword,
                         wchar_t* pszFile,
                         DWORD dwDesiredAccess );
HANDLE _openFileAsUser2( wchar_t* pszAuthority,
                         wchar_t* pszPrincipal,
                         wchar_t* pszPassword,
                         wchar_t* pszFile,
                         DWORD dwDesiredAccess );
HANDLE _getEffectiveToken(DWORD dwDesiredAccess,
                           BOOL bWantImpToken,
   SECURITY_IMPERSONATION_LEVEL impLevel);
HANDLE _getClientToken();
