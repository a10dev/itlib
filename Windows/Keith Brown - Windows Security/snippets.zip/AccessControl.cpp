// AccessControl.cpp
#include "stdafx.h"

// interface dependencies
#include "AccessControl.h"

// implementation dependencies
#include "Principals.h"
#include "LogonSessions.h"
#include <stdio.h>
#include <crtdbg.h>

void* g_pOwner = 0; // for exposition purposes only
ACL*  g_pDacl  = 0; // for exposition purposes only

static void CodeSnippet1() {
// here we use a SECURITY_DESCRIPTOR to communicate
// security information *to* the system
SECURITY_DESCRIPTOR sd; // absolute SD
InitializeSecurityDescriptor( &sd,
    SECURITY_DESCRIPTOR_REVISION );
SetSecurityDescriptorOwner( &sd, g_pOwner, FALSE );
SetSecurityDescriptorDacl ( &sd, TRUE, g_pDacl, FALSE );

SECURITY_ATTRIBUTES sa = { sizeof sa, &sd, FALSE };
HANDLE hMutex = CreateMutex( &sa, FALSE, L"MyMutex" );
// ...
CloseHandle( hMutex );

// here we use a SECURITY_DESCRIPTOR to retrieve
// security information *from* the system
void* psd = 0; // self-relative SD
if ( GetNamedSecurityInfo( L"c:\\foo.txt",
    SE_FILE_OBJECT, DACL_SECURITY_INFORMATION,
    0, 0, 0, 0, &psd ) ) {
    // do something with the information...
    LocalFree( psd ); // one call frees the SD
}
}

bool _isSelfRelativeSD(void* psd) {
  // SECURITY_DESCRIPTOR_CONTROL == WORD
  SECURITY_DESCRIPTOR_CONTROL control;
  DWORD rev;
  if (!GetSecurityDescriptorControl(psd, &control, &rev))
    throw "whoops, you passed a bad security descriptor";
  return (control & SE_SELF_RELATIVE) ? true : false;
}

static void CodeSnippet2() {

// construct an empty DACL
ACL acl;
InitializeAcl( &acl, sizeof acl, ACL_REVISION );

// here we use a SECURITY_DESCRIPTOR to communicate
// the DACL to the system
SECURITY_DESCRIPTOR sd;
InitializeSecurityDescriptor( &sd,
    SECURITY_DESCRIPTOR_REVISION );
SetSecurityDescriptorDacl( &sd, TRUE, &acl, FALSE );

SECURITY_ATTRIBUTES sa = { sizeof sa, &sd, FALSE };
HANDLE hMutex = CreateMutex( &sa, FALSE, L"MyMutex" );
// ...
CloseHandle(hMutex);
}


static void CodeSnippet3() {

// here we use a SECURITY_DESCRIPTOR to communicate
// that we don't want *any DACL at all*
SECURITY_DESCRIPTOR sd;
InitializeSecurityDescriptor( &sd,
    SECURITY_DESCRIPTOR_REVISION );
SetSecurityDescriptorDacl( &sd, TRUE, 0, FALSE );

SECURITY_ATTRIBUTES sa = { sizeof sa, &sd, FALSE };
HANDLE hMutex = CreateMutex( &sa, FALSE, L"MyMutex" );
// ...
CloseHandle( hMutex );
}

// this is just for exposition, to make the code snippet compile
struct Widgit {
    BOOL m_bGenerateAuditOnClose;
};
static void* _getWidgitSD( DWORD widgitId ) { return 0; }
static Widgit* _getWidgit( DWORD widgitId ) { return 0; }
static GENERIC_MAPPING g_widgitGenericMapping;

// imagine we were storing our widgit's security
// descriptors in a database somewhere...
extern void* _getWidgitSD( DWORD widgitId );
extern Widgit* _getWidgit( DWORD widgitId );

Widgit* _tryToOpenWidgit( DWORD widgitId,
                          DWORD dwDesiredAccess ) {
    // to keep this short, I skip obvious error checks
    void* psd = _getWidgitSD( widgitId );

    // from chapter ZZZ_LOGONSESSIONS
    HANDLE htok = _getEffectiveToken(TOKEN_QUERY,
                                     TRUE,
                                     SecurityIdentification);

    // perform the access check
    PRIVILEGE_SET privSet;
    DWORD cbprivSet = sizeof privSet;
    DWORD dwGrantedAccess;
    BOOL bAccessGranted;
    if ( !AccessCheck( psd, htok, dwDesiredAccess,
        &g_widgitGenericMapping, &privSet, &cbprivSet,
        &dwGrantedAccess, &bAccessGranted )
        || !bAccessGranted ) {
        SetLastError(ERROR_ACCESS_DENIED);
        return 0;
    }

    // open the object
    Widgit* pWidgit = _getWidgit( widgitId );

    // perform the audit
    if ( !ObjectOpenAuditAlarm( L"WidgitSubsystem",
        pWidgit, L"Widgit", L"",
        psd, htok, dwDesiredAccess,
        dwGrantedAccess, &privSet,
        FALSE, bAccessGranted,
        &pWidgit->m_bGenerateAuditOnClose ) ) {
        delete pWidgit;
    }
    return pWidgit;
}

void _closeWidgit( Widgit* pWidgit ) {
    ObjectCloseAuditAlarm( L"WidgitSubsystem",
        pWidgit, pWidgit->m_bGenerateAuditOnClose );
    delete pWidgit;
}

// this is just for exposition, to make the code snippet compile
extern ACL* g_psacl;

static void CodeSnippet4() {

// first enable SeSecurityPrivilege
HANDLE htok;
OpenProcessToken( GetCurrentProcess(),
                  TOKEN_QUERY | TOKEN_ADJUST_PRIVILEGES,
                  &htok );
TOKEN_PRIVILEGES tpOld;
if ( !_enablePrivilege( htok, SE_SECURITY_NAME,
                        true, tpOld ) )
    throw "You need to have SeSecurityPrivilege!";

// open a session to the current thread,
// requesting read/write access to its SACL
HANDLE hThread = OpenThread( ACCESS_SYSTEM_SECURITY,
                             FALSE,
                             GetCurrentThreadId() );
// don't need that privilege anymore
_restorePrivilege( htok, tpOld );

// set the SACL
SetSecurityInfo( hThread, SE_KERNEL_OBJECT,
                 SACL_SECURITY_INFORMATION,
                 0, 0, 0, g_psacl );

CloseHandle( hThread );
}

static void CodeSnippet5() {
// first enable SeSecurityPrivilege
HANDLE htok;
OpenProcessToken( GetCurrentProcess(),
                  TOKEN_QUERY | TOKEN_ADJUST_PRIVILEGES,
                  &htok );
TOKEN_PRIVILEGES tpOld;
if ( !_enablePrivilege( htok, SE_SECURITY_NAME,
                        true, tpOld ) )
    throw "You need to have SeSecurityPrivilege!";


// set the SACL
SetNamedSecurityInfo( L"c:\\foo.txt", SE_FILE_OBJECT,
                      SACL_SECURITY_INFORMATION,
                      0, 0, 0, g_psacl );

// don't need that privilege anymore
_restorePrivilege( htok, tpOld );
}

static void CodeSnippet6() {
// form the SID for BUILTIN\Administrators
SIDWithTwoSubauthorities sid = {
    SID_REVISION, 2,
    SECURITY_NT_AUTHORITY,
    SECURITY_BUILTIN_DOMAIN_RID,
    DOMAIN_ALIAS_RID_ADMINS
};
DWORD cb = sizeof(ACL) + _maxVersion2AceSize;
ACL* pdacl = (ACL*)malloc(cb);
InitializeAcl(pdacl, cb, ACL_REVISION);
AddAccessAllowedAceEx(pdacl, ACL_REVISION, 0,
                      FILE_LIST_DIRECTORY, &sid);

SetNamedSecurityInfo(L"c:\\d\\e", SE_FILE_OBJECT,
                     DACL_SECURITY_INFORMATION,
                     0, 0, pdacl, 0);
free(pdacl);
}

static void CodeSnippet7() {
// form the SID for BUILTIN\Guests
SIDWithTwoSubauthorities sid = {
    SID_REVISION, 2,
    SECURITY_NT_AUTHORITY,
    SECURITY_BUILTIN_DOMAIN_RID,
    DOMAIN_ALIAS_RID_GUESTS
};
DWORD cb = sizeof(ACL) + _maxVersion2AceSize;
ACL* pdacl = (ACL*)malloc(cb);
InitializeAcl(pdacl, cb, ACL_REVISION);
AddAccessDeniedAceEx(pdacl, ACL_REVISION,
     CONTAINER_INHERIT_ACE | OBJECT_INHERIT_ACE,
     FILE_ALL_ACCESS, &sid);

SetNamedSecurityInfo(L"c:\\d", SE_FILE_OBJECT,
                     DACL_SECURITY_INFORMATION,
                     0, 0, pdacl, 0);
free(pdacl);
}

static void CodeSnippet8() {
// form the SID for Everyone
SID sid = {SID_REVISION, 1,
           SECURITY_WORLD_SID_AUTHORITY,
           SECURITY_WORLD_RID};
DWORD cb = sizeof(ACL) + _maxVersion2AceSize;
ACL* pdacl = (ACL*)malloc(cb);
InitializeAcl(pdacl, cb, ACL_REVISION);
AddAccessAllowedAceEx(pdacl, ACL_REVISION,
     CONTAINER_INHERIT_ACE | OBJECT_INHERIT_ACE,
     FILE_ALL_ACCESS, &sid);

SetNamedSecurityInfo(L"c:\\d", SE_FILE_OBJECT,
              DACL_SECURITY_INFORMATION |
              PROTECTED_DACL_SECURITY_INFORMATION,
              0, 0, pdacl, 0);
free(pdacl);
}

// CodeSnippet9 definitions are used in later snippets

// excerpt from FOLDER.H
// first define the specific permissions for folders
#define FOLDER_LIST_CONTENTS 0x00000001
#define FOLDER_ADD_ITEM      0x00000002
#define FOLDER_DELETE_ITEM   0x00000003

// group standard and specific permissions into the four
// categories of generic permissions (this is useful for
// documentation purposes so people know what they are
// getting when they use generic permissions)
#define FOLDER_READ      (STANDARD_RIGHTS_READ     |\
                          FOLDER_LIST_CONTENTS)

#define FOLDER_WRITE     (STANDARD_RIGHTS_WRITE    |\
                          FOLDER_ADD_ITEM          |\
                          FOLDER_DELETE_ITEM)

#define FOLDER_EXECUTE   (STANDARD_RIGHTS_EXECUTE)

#define FOLDER_ALL       (STANDARD_RIGHTS_REQUIRED |\
                          FOLDER_READ              |\
                          FOLDER_WRITE             |\
                          FOLDER_EXECUTE)

// excerpt from FOLDER.CPP
GENERIC_MAPPING g_gmFolder = {
  FOLDER_READ,     // GenericRead
  FOLDER_WRITE,    // GenericWrite
  FOLDER_EXECUTE,  // GenericExecute
  FOLDER_ALL       // GenericAll
};

// this placeholder is here to make the next code snippet compile
void* _getFactoryObjectSD() { return 0; }

static void CodeSnippet10() {
// imagine that we've previously constructed a security
// descriptor for the factory...
void* psdParent = _getFactoryObjectSD();

// retrieve the current security context
// (this was discussed in the chapter on logon sessions)
HANDLE htok = _getEffectiveToken(TOKEN_QUERY, FALSE, SecurityIdentification);

void* psdFolder = 0;
CreatePrivateObjectSecurity(psdParent, 0, &psdFolder,
                            TRUE, htok, &g_gmFolder);

// if everything went OK, psdFolder should now point to
// a fully formed security descriptor for the folder
}

void _dumpDacl(ACL* pdacl) {
  ACL_SIZE_INFORMATION sizeInfo;
  GetAclInformation(pdacl,
                    &sizeInfo, sizeof sizeInfo,
                    AclSizeInformation);

  for (DWORD i = 0; i < sizeInfo.AceCount; ++i) {
    // allow/deny aces have exactly the same shape
    ACCESS_ALLOWED_ACE* pace;
    GetAce(pdacl, i, (void**)&pace);
  
    const wchar_t* pszGrantOrDeny;
    switch (pace->Header.AceType) {
    case ACCESS_ALLOWED_ACE_TYPE:
      pszGrantOrDeny = L"grant";
      break;
    case ACCESS_DENIED_ACE_TYPE:
      pszGrantOrDeny = L"deny";
      break;
    default:
      pszGrantOrDeny = L"<<unexpected ace type>>";
      break;
    }
    wprintf(L"%s 0x%08X (inh: %X) to ",
      pszGrantOrDeny,
      pace->Mask,
      pace->Header.AceFlags);

    _printSid(&pace->SidStart);
    wprintf(L"\n");
  }
}

ACL* _insertAccessAllowedAce(ACL* pdaclOld,
                             DWORD grfMask,
                             DWORD grfInherit,
                             PSID psid) {
  ACL_SIZE_INFORMATION si;
  GetAclInformation(pdaclOld, &si, sizeof si,
                    AclSizeInformation);

  // allocate a DACL with room for one additional ACE
  DWORD cb = si.AclBytesInUse + _maxVersion2AceSize;
  ACL* pdaclNew = (ACL*)LocalAlloc(GPTR, cb);

  InitializeAcl(pdaclNew, cb, ACL_REVISION);
  
  // a safe way to add a direct positive ACE is to
  // add it right before the inherited ACEs begin
  bool bInserted = false;
  for (DWORD i = 0; i < si.AceCount; ++i) {
    ACE_HEADER* pace;
    GetAce(pdaclOld, i, (void**)&pace);
    if (!bInserted && pace->AceFlags & INHERITED_ACE) {
      AddAccessAllowedAceEx(pdaclNew, ACL_REVISION,
                            grfInherit, grfMask, psid);
      bInserted = true;
    }
    AddAce(pdaclNew, ACL_REVISION, MAXDWORD,
           pace, pace->AceSize);
  }
  if (!bInserted)
      AddAccessAllowedAceEx(pdaclNew, ACL_REVISION,
                            grfInherit, grfMask, psid);
  return pdaclNew;
}

ACL* _insertAccessDeniedAce(ACL* pdaclOld,
                            DWORD grfMask,
                            DWORD grfInherit,
                            PSID psid) {
  ACL_SIZE_INFORMATION si;
  GetAclInformation(pdaclOld, &si, sizeof si,
                    AclSizeInformation);

  // allocate a DACL with room for one additional ACE
  DWORD cb = si.AclBytesInUse + _maxVersion2AceSize;
  ACL* pdaclNew = (ACL*)LocalAlloc(GPTR, cb);

  InitializeAcl(pdaclNew, cb, ACL_REVISION);
  
  // a safe way to add a direct negative ACE is to
  // add it at the very beginning of the ACL
  AddAccessDeniedAceEx(pdaclNew, ACL_REVISION,
                       grfInherit, grfMask, psid);
  for (DWORD i = 0; i < si.AceCount; ++i) {
    ACE_HEADER* pace;
    GetAce(pdaclOld, i, (void**)&pace);
    AddAce(pdaclNew, ACL_REVISION, MAXDWORD,
           pace, pace->AceSize);
  }
  return pdaclNew;
}

#if _WIN32_WINNT < 0x500
BOOL AddAccessAllowedAceEx(PACL pAcl,
                           DWORD dwAceRevision,
                           DWORD AceFlags,
                           DWORD AccessMask,
                           PSID pSid) {
  if (!AddAccessAllowedAce(pAcl, dwAceRevision,
                           AccessMask, pSid))
    return FALSE;
  ACL_SIZE_INFORMATION info;
  if (!GetAclInformation(pAcl, &info, sizeof info,
                         AclSizeInformation))
    return FALSE;
  ACE_HEADER* pace = 0;
  if (!GetAce(pAcl, info.AceCount - 1, (void**)&pace))
    return FALSE;
  pace->AceFlags = (BYTE)AceFlags;
  return TRUE;
}

BOOL AddAccessDeniedAceEx(PACL pAcl,
                          DWORD dwAceRevision,
                          DWORD AceFlags,
                          DWORD AccessMask,
                          PSID pSid)
{
  if (!AddAccessDeniedAce(pAcl, dwAceRevision,
                          AccessMask, pSid))
    return FALSE;
  ACL_SIZE_INFORMATION info;
  if (!GetAclInformation(pAcl, &info, sizeof info,
                         AclSizeInformation))
    return FALSE;
  ACE_HEADER* pace = 0;
  if (!GetAce(pAcl, info.AceCount - 1, (void**)&pace))
    return FALSE;
  pace->AceFlags = (BYTE)AceFlags;
  return TRUE;
}
#endif

void CodeSnippet11() {
// grant GENERIC_ALL to Everyone
// except Network logon sessions,
// making these ACEs inheritable
SID sidEveryone = {SID_REVISION, 1,
                   SECURITY_WORLD_SID_AUTHORITY,
                   SECURITY_WORLD_RID};
SID sidNetwork  = {SID_REVISION, 1,
                   SECURITY_NT_AUTHORITY,
                   SECURITY_NETWORK_RID};
DWORD cb = 2 * _maxVersion2AceSize;
ACL* pdacl = (ACL*)LocalAlloc(GPTR, cb);

InitializeAcl(pdacl, cb, ACL_REVISION);

DWORD grfInherit = OBJECT_INHERIT_ACE |
                   CONTAINER_INHERIT_ACE;
AddAccessDeniedAceEx( pdacl, ACL_REVISION,
                      grfInherit, GENERIC_ALL,
                      &sidNetwork);
AddAccessAllowedAceEx(pdacl, ACL_REVISION,
                      grfInherit, GENERIC_ALL,
                      &sidEveryone);

// call to Set(Named)SecurityInfo or
// CreatePrivateObjectSecurity(Ex) omitted

// now our (overly fat) DACL is no longer needed
LocalFree(pdacl);
}

void CodeSnippet12() {
// deny GENERIC_ALL to Network logon sessions
SID sidNetwork  = {SID_REVISION, 1,
                   SECURITY_NT_AUTHORITY,
                   SECURITY_NETWORK_RID};
void* psd;
ACL* pdaclOld;
GetNamedSecurityInfo(L"MACHINE\\Software\\Test",
                     SE_REGISTRY_KEY,
                     DACL_SECURITY_INFORMATION,
                     0, 0, &pdaclOld, 0, &psd);

ACL* pdaclNew = _insertAccessDeniedAce(pdaclOld,
                             GENERIC_ALL,
                             CONTAINER_INHERIT_ACE,
                             &sidNetwork);
SetNamedSecurityInfo(L"MACHINE\\Software\\Test",
                     SE_REGISTRY_KEY,
                     DACL_SECURITY_INFORMATION,
                     0, 0, pdaclNew, 0);
LocalFree(pdaclNew);
LocalFree(psd);
}
