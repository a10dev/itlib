// COM.h
#pragma once

long _addViaRPC(long a, long b,
                wchar_t* pszBindingString,
                wchar_t* pszExpectedServerPrincipal);
void _listenForRPCRequests();
