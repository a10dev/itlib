/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Mon Mar 20 03:23:36 2000
 */
/* Compiler settings for foo.idl:
    Os (OptLev=s), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __foo_h__
#define __foo_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IFoo_FWD_DEFINED__
#define __IFoo_FWD_DEFINED__
typedef interface IFoo IFoo;
#endif 	/* __IFoo_FWD_DEFINED__ */


#ifndef __IBar_FWD_DEFINED__
#define __IBar_FWD_DEFINED__
typedef interface IBar IBar;
#endif 	/* __IBar_FWD_DEFINED__ */


#ifndef __IQuux_FWD_DEFINED__
#define __IQuux_FWD_DEFINED__
typedef interface IQuux IQuux;
#endif 	/* __IQuux_FWD_DEFINED__ */


#ifndef __IBaz_FWD_DEFINED__
#define __IBaz_FWD_DEFINED__
typedef interface IBaz IBaz;
#endif 	/* __IBaz_FWD_DEFINED__ */


#ifndef __IHiddenUnion_FWD_DEFINED__
#define __IHiddenUnion_FWD_DEFINED__
typedef interface IHiddenUnion IHiddenUnion;
#endif 	/* __IHiddenUnion_FWD_DEFINED__ */


#ifndef __UseThisToConfigureMethodsForScripts_FWD_DEFINED__
#define __UseThisToConfigureMethodsForScripts_FWD_DEFINED__
typedef interface UseThisToConfigureMethodsForScripts UseThisToConfigureMethodsForScripts;
#endif 	/* __UseThisToConfigureMethodsForScripts_FWD_DEFINED__ */


#ifndef __MyConfiguredClass_FWD_DEFINED__
#define __MyConfiguredClass_FWD_DEFINED__

#ifdef __cplusplus
typedef class MyConfiguredClass MyConfiguredClass;
#else
typedef struct MyConfiguredClass MyConfiguredClass;
#endif /* __cplusplus */

#endif 	/* __MyConfiguredClass_FWD_DEFINED__ */


void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IFoo_INTERFACE_DEFINED__
#define __IFoo_INTERFACE_DEFINED__

/* interface IFoo */
/* [object][uuid] */ 


EXTERN_C const IID IID_IFoo;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("12341230-1234-1234-1234-123412341234")
    IFoo : public IUnknown
    {
    public:
    };
    
#else 	/* C style interface */

    typedef struct IFooVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IFoo __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IFoo __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IFoo __RPC_FAR * This);
        
        END_INTERFACE
    } IFooVtbl;

    interface IFoo
    {
        CONST_VTBL struct IFooVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IFoo_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IFoo_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IFoo_Release(This)	\
    (This)->lpVtbl -> Release(This)


#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IFoo_INTERFACE_DEFINED__ */


#ifndef __IBar_INTERFACE_DEFINED__
#define __IBar_INTERFACE_DEFINED__

/* interface IBar */
/* [object][uuid] */ 


EXTERN_C const IID IID_IBar;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("12341231-1234-1234-1234-123412341234")
    IBar : public IUnknown
    {
    public:
    };
    
#else 	/* C style interface */

    typedef struct IBarVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IBar __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IBar __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IBar __RPC_FAR * This);
        
        END_INTERFACE
    } IBarVtbl;

    interface IBar
    {
        CONST_VTBL struct IBarVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IBar_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IBar_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IBar_Release(This)	\
    (This)->lpVtbl -> Release(This)


#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IBar_INTERFACE_DEFINED__ */


#ifndef __IQuux_INTERFACE_DEFINED__
#define __IQuux_INTERFACE_DEFINED__

/* interface IQuux */
/* [object][uuid] */ 


EXTERN_C const IID IID_IQuux;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("12341232-1234-1234-1234-123412341234")
    IQuux : public IUnknown
    {
    public:
    };
    
#else 	/* C style interface */

    typedef struct IQuuxVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IQuux __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IQuux __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IQuux __RPC_FAR * This);
        
        END_INTERFACE
    } IQuuxVtbl;

    interface IQuux
    {
        CONST_VTBL struct IQuuxVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IQuux_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IQuux_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IQuux_Release(This)	\
    (This)->lpVtbl -> Release(This)


#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IQuux_INTERFACE_DEFINED__ */


#ifndef __IBaz_INTERFACE_DEFINED__
#define __IBaz_INTERFACE_DEFINED__

/* interface IBaz */
/* [object][uuid] */ 


EXTERN_C const IID IID_IBaz;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("12341233-1234-1234-1234-123412341234")
    IBaz : public IUnknown
    {
    public:
    };
    
#else 	/* C style interface */

    typedef struct IBazVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IBaz __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IBaz __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IBaz __RPC_FAR * This);
        
        END_INTERFACE
    } IBazVtbl;

    interface IBaz
    {
        CONST_VTBL struct IBazVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IBaz_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IBaz_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IBaz_Release(This)	\
    (This)->lpVtbl -> Release(This)


#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IBaz_INTERFACE_DEFINED__ */



#ifndef __Foo_LIBRARY_DEFINED__
#define __Foo_LIBRARY_DEFINED__

/* library Foo */
/* [uuid] */ 


EXTERN_C const IID LIBID_Foo;

#ifndef __IHiddenUnion_INTERFACE_DEFINED__
#define __IHiddenUnion_INTERFACE_DEFINED__

/* interface IHiddenUnion */
/* [unique][uuid][object] */ 


EXTERN_C const IID IID_IHiddenUnion;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("A51F6D55-AD0E-4EE3-A284-A0805B996BAF")
    IHiddenUnion : public IUnknown
    {
    public:
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Foo( void) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Bar( void) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Quux( void) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Baz( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IHiddenUnionVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IHiddenUnion __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IHiddenUnion __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IHiddenUnion __RPC_FAR * This);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Foo )( 
            IHiddenUnion __RPC_FAR * This);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Bar )( 
            IHiddenUnion __RPC_FAR * This);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Quux )( 
            IHiddenUnion __RPC_FAR * This);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Baz )( 
            IHiddenUnion __RPC_FAR * This);
        
        END_INTERFACE
    } IHiddenUnionVtbl;

    interface IHiddenUnion
    {
        CONST_VTBL struct IHiddenUnionVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IHiddenUnion_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IHiddenUnion_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IHiddenUnion_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IHiddenUnion_Foo(This)	\
    (This)->lpVtbl -> Foo(This)

#define IHiddenUnion_Bar(This)	\
    (This)->lpVtbl -> Bar(This)

#define IHiddenUnion_Quux(This)	\
    (This)->lpVtbl -> Quux(This)

#define IHiddenUnion_Baz(This)	\
    (This)->lpVtbl -> Baz(This)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [id] */ HRESULT STDMETHODCALLTYPE IHiddenUnion_Foo_Proxy( 
    IHiddenUnion __RPC_FAR * This);


void __RPC_STUB IHiddenUnion_Foo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IHiddenUnion_Bar_Proxy( 
    IHiddenUnion __RPC_FAR * This);


void __RPC_STUB IHiddenUnion_Bar_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IHiddenUnion_Quux_Proxy( 
    IHiddenUnion __RPC_FAR * This);


void __RPC_STUB IHiddenUnion_Quux_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IHiddenUnion_Baz_Proxy( 
    IHiddenUnion __RPC_FAR * This);


void __RPC_STUB IHiddenUnion_Baz_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IHiddenUnion_INTERFACE_DEFINED__ */


#ifndef __UseThisToConfigureMethodsForScripts_DISPINTERFACE_DEFINED__
#define __UseThisToConfigureMethodsForScripts_DISPINTERFACE_DEFINED__

/* dispinterface UseThisToConfigureMethodsForScripts */
/* [uuid] */ 


EXTERN_C const IID DIID_UseThisToConfigureMethodsForScripts;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("A5148D55-AD0E-4EE3-A284-A0805B996BAF")
    UseThisToConfigureMethodsForScripts : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct UseThisToConfigureMethodsForScriptsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            UseThisToConfigureMethodsForScripts __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            UseThisToConfigureMethodsForScripts __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            UseThisToConfigureMethodsForScripts __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            UseThisToConfigureMethodsForScripts __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            UseThisToConfigureMethodsForScripts __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            UseThisToConfigureMethodsForScripts __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            UseThisToConfigureMethodsForScripts __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } UseThisToConfigureMethodsForScriptsVtbl;

    interface UseThisToConfigureMethodsForScripts
    {
        CONST_VTBL struct UseThisToConfigureMethodsForScriptsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define UseThisToConfigureMethodsForScripts_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define UseThisToConfigureMethodsForScripts_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define UseThisToConfigureMethodsForScripts_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define UseThisToConfigureMethodsForScripts_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define UseThisToConfigureMethodsForScripts_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define UseThisToConfigureMethodsForScripts_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define UseThisToConfigureMethodsForScripts_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* __UseThisToConfigureMethodsForScripts_DISPINTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_MyConfiguredClass;

#ifdef __cplusplus

class DECLSPEC_UUID("0863E813-6C99-4296-983F-7A5C06588E4B")
MyConfiguredClass;
#endif
#endif /* __Foo_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
