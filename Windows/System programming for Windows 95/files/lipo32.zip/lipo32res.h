#define IDI_ICON1	1
#define IDD_DIALOG1                     101
#define IDC_STRIP_DEBUG_INFO            1000
#define IDC_REMOVE_RELOCATIONS          1001
#define IDC_BIND                        1002
#define IDC_INCREMENTAL_LINKING         1004
#define IDC_UNOPTIMIZED_CODE            1005
#define IDC_RELOCATIONS                 1006
#define IDC_DEBUG_INFO                  1007
#define IDC_COMBINABLE_SECTIONS         1008
#define IDC_LOAD_CONFLICTS              1009
#define IDC_FILENAME                    1010
#define IDC_IMAGE_BOUND                 1011
#define IDC_UNINITIALIZED_DATA          1012

