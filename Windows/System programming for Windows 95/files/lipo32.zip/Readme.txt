This is the code from my October 1996 "Liposuction" article.

You can read the original article at
http://www.microsoft.com/msj/defaulttop.asp?page=/msj/archive/s572.htm

I haven't updated this code, except to change one function prototype
to match more recent Microsoft headers.  It was originally written using
VC 4.1, and it shows!

The VC6 linker does a pretty good job of building executables in release mode,
so don't be surprised if LIPO32 doesn't find much.

To build from the command line, run BUILD.BAT

Lipo32 is the command line version, and Liposuction32 is the GUI version.

Comments are welcome, but I'm not planning on actively updating this utility
unless something major comes along.  Suggestions anybody?

