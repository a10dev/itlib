// DbgHelpDemo.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "cvconst.h"

BOOL CALLBACK EnumerateSymbolsCallback( PSYMBOL_INFO , ULONG, PVOID );
BOOL CALLBACK EnumSourceFilesCallback( PSOURCEFILE, PVOID );
char * SymTagAsString( DWORD symTag );
char * BaseTypeAsString( DWORD baseType );

int main(int argc, char* argv[])
{
	if ( argc != 2 )
	{
		printf( "Syntax: DbgHelpDemo <filename>\n" );
		return 1;
	}
	char * pszExeName = argv[1];

	HANDLE hProcess = 0;

    //
    // Init symbol handler for "process" (in our case, "0" is the process)
    //          
    if ( !SymInitialize( hProcess, 0, FALSE ) )
    {
        printf( "SymInitialize failed\n" );
        return 1;
    }

    //
    // Load the symbol table for the specified file.  A "MappedAddress" from
    // MapAndLoad, or a "MappedBase" from MapDebugInformation is needed as
    // parameter 5.
    //
	DWORD dwModuleBase = SymLoadModule( hProcess, 0, pszExeName, 0, 0, 0 );

    if ( !dwModuleBase )
    {
        printf( "SymLoadModuleFailed\n" );
        return 1;
    }

	IMAGEHLP_MODULE im = { sizeof(im) };
	SymGetModuleInfo( hProcess, dwModuleBase, &im );

	if ( im.SymType == SymExport )
	{
		printf( "Only Export symbols - skipping\r\n");
		return false;
	}

	if ( im.SymType == SymNone )
	{
		printf( "No Symbols - skipping\r\n");
		return false;
	}

	printf( "Symbols OK\n");

	printf( "Symbols\n" );	// Note: SymEnumSymbols, rather than older SymEnumerateSymbols

    SymEnumSymbols( hProcess, dwModuleBase, 0, EnumerateSymbolsCallback, 0 );

	printf( "Types\n" );		// New in XP DBGHELP.DLL
	SymEnumTypes( hProcess, dwModuleBase, EnumerateSymbolsCallback, 0 );

	printf( "Source Files\n" );		// New in XP DBGHELP.DLL
	SymEnumSourceFiles( hProcess, dwModuleBase, "*.*", EnumSourceFilesCallback, 0 );

	SymUnloadModule( hProcess, dwModuleBase );  // Undo SymLoadModule

    SymCleanup( hProcess );                // Undo the SymInitialize

	return 0;
}

void DumpUDTTypeIndex( DWORD dwTypeIndex, unsigned nestingLevel, unsigned offset )
{
	struct FINDCHILDREN : TI_FINDCHILDREN_PARAMS
	{
		ULONG	MoreChildIds[0x1000];
	public:
		FINDCHILDREN(){ Count = sizeof(MoreChildIds) / sizeof(MoreChildIds[0]); }
	};

	DWORD childrenCount;
	if ( SymGetTypeInfo( 0, 0, dwTypeIndex, TI_GET_CHILDRENCOUNT, &childrenCount ) && childrenCount )
	{
		assert( childrenCount < 0x1000 );

		FINDCHILDREN children;
		children.Count = childrenCount;
		children.Start= 0;
		if ( SymGetTypeInfo( 0, 0, dwTypeIndex, TI_FINDCHILDREN, &children ) )
		{
			for ( unsigned i = 0; i < childrenCount; i++ )
			{
				WCHAR * pwszMemberName = L"";
				SymGetTypeInfo( 0, 0, children.ChildId[i], TI_GET_SYMNAME, &pwszMemberName );

				DWORD typeId = 0;
				SymGetTypeInfo( 0, 0, children.ChildId[i], TI_GET_TYPEID, &typeId);

				DWORD baseType = 0;
				SymGetTypeInfo( 0, 0, typeId, TI_GET_BASETYPE, &baseType);

				WCHAR * pwszTypeName = L"";
				SymGetTypeInfo( 0, 0, typeId, TI_GET_SYMNAME, &pwszTypeName );

				DWORD memberOffset;
				SymGetTypeInfo( 0, 0, children.ChildId[i], TI_GET_OFFSET, &memberOffset );

				DWORD symTag;
				SymGetTypeInfo( 0, 0, children.ChildId[i], TI_GET_SYMTAG, &symTag );

				DWORD dataKind = 0;
				SymGetTypeInfo( 0, 0, children.ChildId[i], TI_GET_DATAKIND, &dataKind );

				DWORD symIndex = 0;
				SymGetTypeInfo( 0, 0, children.ChildId[i], TI_GET_SYMINDEX, &symIndex);

				DWORD elementCount = 0;
				SymGetTypeInfo( 0, 0, typeId, TI_GET_COUNT, &elementCount );

				ULONG64 typeLength = 0;
				SymGetTypeInfo( 0, 0, typeId, TI_GET_LENGTH, &typeLength);

				for ( unsigned j = 0; j < nestingLevel; j++ )
					printf( "\t" );

				printf( "\t\tmember:%X  %ls  %ls  Offs:%X  SymTag:%s  typeId:%X  baseType:%s elements:%X  size:%I64X",
						children.ChildId[i], pwszTypeName, pwszMemberName, offset + memberOffset,
						SymTagAsString(symTag), typeId,
						BaseTypeAsString(baseType), elementCount, typeLength );

				/*
				if ( symTag == SymTagEnum )
				{
					VARIANT variant;
					SymGetTypeInfo( 0, 0, typeId, TI_GET_VALUE, &variant );
					printf( " value:%X", variant.lVal );
				}
				*/

				printf( "\n" );

				DWORD dwChildCount;
				if ( SymGetTypeInfo( 0, 0, typeId, TI_GET_CHILDRENCOUNT, &dwChildCount ) && (dwChildCount > 0) )
				{
					// Recurse to get subtypes
					DumpUDTTypeIndex( typeId, nestingLevel+1, offset + memberOffset );
				}				
			}
		}
	}
}

BOOL CALLBACK EnumerateSymbolsCallback(
    PSYMBOL_INFO  pSymInfo,
    ULONG         SymbolSize,
    PVOID         UserContext )
{
	if ( UserContext != 0 )
		printf( "\t" );

	printf( "%s size:%X  Addr: %p", pSymInfo->Name, pSymInfo->Size, pSymInfo->Address );

	printf( " TypeIndex: %X", pSymInfo->TypeIndex );

	// Get the "real" type index for this symbol
	DWORD typeId = 0;
	SymGetTypeInfo( 0, 0, pSymInfo->TypeIndex, TI_GET_TYPEID, &typeId);

	// Display the base type
	DWORD baseType = 0;
	SymGetTypeInfo( 0, 0, typeId, TI_GET_BASETYPE, &baseType);

	printf( " BaseType:%s", BaseTypeAsString(baseType) );

	printf( " Tag:%s", SymTagAsString(pSymInfo->Tag) );

	if ( pSymInfo->Address )
	{
		WCHAR * pwszTypeName;
		if ( SymGetTypeInfo( 0, pSymInfo->ModBase, pSymInfo->TypeIndex, TI_GET_SYMNAME, &pwszTypeName ) )
		{
			printf( "  TypeName: %ls", pwszTypeName );
			LocalFree( pwszTypeName );
		}
	}

	if ( pSymInfo->Flags & IMAGEHLP_SYMBOL_INFO_VALUEPRESENT ) printf( " VALUEPRESENT" );
	if ( pSymInfo->Flags & IMAGEHLP_SYMBOL_INFO_REGISTER ) printf( " REGISTER" );
	if ( pSymInfo->Flags & IMAGEHLP_SYMBOL_INFO_REGISTER ) printf( " reg:%u", pSymInfo->Register );
	if ( pSymInfo->Flags & IMAGEHLP_SYMBOL_INFO_REGRELATIVE ) printf( " REGRELATIVE" );
	if ( pSymInfo->Flags & IMAGEHLP_SYMBOL_INFO_REGRELATIVE ) printf( " reg:%u", pSymInfo->Register );
	if ( pSymInfo->Flags & IMAGEHLP_SYMBOL_INFO_FRAMERELATIVE ) printf( " FRAMERELATIVE" );
	if ( pSymInfo->Flags & IMAGEHLP_SYMBOL_INFO_PARAMETER ) printf( " PARAMETER" );
	if ( pSymInfo->Flags & IMAGEHLP_SYMBOL_INFO_LOCAL ) printf( " LOCAL" );
	if ( pSymInfo->Flags & IMAGEHLP_SYMBOL_INFO_CONSTANT ) printf( " CONSTANT" );
	if ( pSymInfo->Flags & IMAGEHLP_SYMBOL_FUNCTION ) printf( " FUNCTION" );

	printf( "\n" );

	if ( UserContext == (PVOID)1 )
	{
		DumpUDTTypeIndex( pSymInfo->TypeIndex, 0, 0 );
	}

	if ( pSymInfo->Tag == SymTagFunction )
	{
		IMAGEHLP_STACK_FRAME ihst;
		memset( &ihst, 0, sizeof(ihst) );
		ihst.InstructionOffset = pSymInfo->Address;
		SymSetContext( 0, &ihst, 0 );
		SymEnumSymbols( 0, 0, 0, EnumerateSymbolsCallback, (PVOID)1 );
	}
	else if ( pSymInfo->Tag == SymTagUDT )
	{
		DumpUDTTypeIndex( pSymInfo->TypeIndex, 0, 0 );
	}

	return true;
}

BOOL CALLBACK EnumSourceFilesCallback(
    PSOURCEFILE pSourceFile,
    PVOID       UserContext )
{
	printf( "\t%s\n", pSourceFile->FileName );
	return true;
}

char * SymTagAsString( DWORD symTag )
{
	switch( symTag )
	{
		case SymTagFunction: return "function"; break;
		case SymTagData: return "Data"; break;
		case SymTagPublicSymbol: return "PublicSymbol"; break;
		case SymTagUDT: return "UDT"; break;
		case SymTagEnum: return "Enum"; break;
		case SymTagTypedef: return "Typedef"; break;
		default: return "???";
	}
}

char * BaseTypeAsString( DWORD baseType )
{
	switch ( baseType )
	{
	case btNoType: return "btNoType";
	case btVoid: return "btVoid";
	case btChar: return "btChar";
	case btWChar: return "btWChar";
	case btInt: return "btInt";
	case btUInt: return "btUInt";
	case btFloat: return "btFloat";
	case btBCD: return "btBCD";
	case btBool: return "btBool";
	case btLong: return "btLong";
	case btULong: return "btULong";
	case btCurrency: return "btCurrency";
	case btDate: return "btDate";
	case btVariant: return "btVariant";
	case btComplex: return "btComplex";
	case btBit: return "btBit";
	case btBSTR: return "btBSTR";
	case btHresult: return "btHresult";
	default: return "???";
	}
}
