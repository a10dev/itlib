To run DbgHelpDemo, run it against the EXE or DLL, not the .PDB file.

For instance, if you want to dump out NTDLL's symbols, you'll need to
run it against NTDLL.DLL.  For instance:

DbgHelpDemo c:\winnt\system32\ntdll.dll


Note that DbgHelp.DLL (not my DbgHelpDemo) code is responsible for
locating the matching PDB files.  If they're not in the symbol file
path, you probably won't have much luck.  Personally, I just make
sure that the DLL and its PDB are in the same directory.  Your 
mileage may vary.
