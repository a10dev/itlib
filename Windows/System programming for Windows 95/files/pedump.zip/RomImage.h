void DumpROMImage( PIMAGE_ROM_HEADERS );
