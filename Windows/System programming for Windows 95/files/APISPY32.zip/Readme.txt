This is an updated version of APISPY32 that appears in "Windows 95 System
Programming Secrets".

First off, let me state that this is old code.  This was my coding style circa
1995.  If I were to write this program today, it would be much more structured
and more robust.  I did the minimal amount of work to get it running again to
make it available.  Ditto with the .MAK files.

To build the program, run BUILD.BAT.  It builds APISPYLD.EXE (the loader), and
APISPY32.DLL (the DLL that's injected for spying).  If you don't have MASM,
don't bother trying to build it.  I've included the necessary pre-built
binaries.

To use the program, run APISPYLD.EXE.  Specify an EXE name to spy on, and hit
"Run".   After the target program terminates, there should be an .OUT file in
the same directory as the target program.  For instance, if you run
C:\WINNT\SYSTEM32\CALC.EXE, you should have C:\WINNT\SYSTEM32\CALC.OUT.

The .OUT is a text file.  View with any editor.

Note that the spying only occurs on program made from the main EXE.  Calls from
DLLs aren't logged.  That's left as an exercise to the reader.

Also, note that the API list is now very incomplete.  It only has definitions
for some of the basic system DLLs and APIs that were around in the 1995 time
frame.  If somebody wants to send me updated definitions, I'll happily post
them.

Note:  I've replaced the original debug loop injection code with newer code that
runs on Win2K.  This code is in DebugInjector.CPP/.H, and is essentially the
same injector code that I wrote for my Feb. 2000 MSDN column (DelayLoadProfile)
There is one minor bug fix to the original DebugInjector code.

While I welcome comments, this is essentially unsupported code.  I'm not
planning on overhauling it or making any additions to it.  I'm simply providing
it as a service for those people who want it.
