extern char * _ppszArgv[];

int __cdecl _ConvertCommandLineToArgcArgv( void );
