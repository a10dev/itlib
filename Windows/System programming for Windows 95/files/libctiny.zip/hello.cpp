//==========================================
// LIBCTINY - Matt Pietrek 2001
// MSDN Magazine, January 2001
//==========================================
#include <stdio.h>

void main()
{
    printf ("Hello World!\n" );
}
